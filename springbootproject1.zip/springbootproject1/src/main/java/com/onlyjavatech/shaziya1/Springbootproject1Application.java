package com.onlyjavatech.shaziya1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootproject1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootproject1Application.class, args);
	}

}
