package com.onlyjavatech.shaziya1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootproject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
